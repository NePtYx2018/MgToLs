bash .banner
echo "Que deseas hackear:"
echo "====================="
echo "1)Facebook=2)Twitter="
echo "3)Outlook =4)Gmail  ="
echo "5)Yahoo   =6)Salir  ="
echo "7)Contras ==========="
echo "==========="
read input
bash .$input
