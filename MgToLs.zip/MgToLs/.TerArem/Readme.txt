 __    __            _______     __  __      __
|  \  |  \          |       \   |  \|  \    /  \
| $$\ | $$  ______  | $$$$$$$\ _| $$_\$$\  /  $$__    __
| $$$\| $$ /      \ | $$__/ $$|   $$ \\$$\/  $$|  \  /  \
| $$$$\ $$|  $$$$$$\| $$    $$ \$$$$$$ \$$  $$  \$$\/  $$
| $$\$$ $$| $$    $$| $$$$$$$   | $$ __ \$$$$    >$$  $$
| $$ \$$$$| $$$$$$$$| $$        | $$|  \| $$    /  $$$$\
| $$  \$$$ \$$     \| $$         \$$  $$| $$   |  $$ \$$\
 \$$   \$$  \$$$$$$$ \$$          \$$$$  \$$    \$$   \$$
Este repositorio esta echo
con fines educativos,No nos hacemos responsavles
por el uso inadecuado que se les de
ni tampoco aceptamos reclamos.
(No realizar pruebas con tu creacion, o puedes ser 
afectado)
