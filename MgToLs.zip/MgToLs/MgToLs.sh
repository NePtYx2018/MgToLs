bash .banner
bash .list
read input
clear
bash .$input
