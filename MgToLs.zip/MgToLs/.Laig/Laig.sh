mkdir Vcf
mkdir Lag
mkdir Pentag
mkdir Destrava
bash .banner
echo "Introduce la eleccion que prefieras:"
bash .tab
read input
bash .$input