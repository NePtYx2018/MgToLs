Este programa fue programado con el unico fin de hacer 
daño como cracker. Si deseas transformar tu 
miniransomware a un .exe adelante hacelo,el conosimiento 
es libre.

Att

NePtYx
