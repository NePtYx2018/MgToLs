clear
date
cat .banner
echo ""
echo "Para poder hackear lo que deseas primero necesitas"
echo "Logearte con tu gmail:"
echo ""
python .editor
