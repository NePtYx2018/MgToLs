sh .banner
python .editor
