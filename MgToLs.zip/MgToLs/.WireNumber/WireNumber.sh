clear
sh .banner
echo "Rastreos Disponivles:"
echo "====================="
echo "America#Del#Sur     ="
echo "America#Del#Centro  ="
echo "America#Del#Norte   ="
echo "====================="
echo "Si es que no te lee el numero,"
echo "es porque no esta en la lista de rastreo."
echo "indroduce el codigo de pais:"
echo "Ejemplo: 549"
read input
sh .$input
