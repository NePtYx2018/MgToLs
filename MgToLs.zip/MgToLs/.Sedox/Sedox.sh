bash .menu |& tee Url.txt


