 _   _      ____  _ __   __
| \ | | ___|  _ \| |\ \ / /_  __
|  \| |/ _ \ |_) | __\ V /\ \/ /
| |\  |  __/  __/| |_ | |  >  <
|_| \_|\___|_|    \__||_| /_/\_\
////////////////////////////////
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

Este repositorio ha sido programado
con fines de doxear a personas y hacer que 
alguien publicamente publicado sea doxxeado
no se aceptan reclamos buenos ni malos.
