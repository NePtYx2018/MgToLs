
       __  __    __            _______     __  __      __          
      /  \|  \  |  \          |       \   |  \|  \    /  \         
     /  $$| $$\ | $$  ______  | $$$$$$$\ _| $$_\$$\  /  $$__    __ 
    /  $$ | $$$\| $$ /      \ | $$__/ $$|   $$ \\$$\/  $$|  \  /  \
   /  $$  | $$$$\ $$|  $$$$$$\| $$    $$ \$$$$$$ \$$  $$  \$$\/  $$
  /  $$   | $$\$$ $$| $$    $$| $$$$$$$   | $$ __ \$$$$    >$$  $$ 
 /  $$    | $$ \$$$$| $$$$$$$$| $$        | $$|  \| $$    /  $$$$\ 
|  $$     | $$  \$$$ \$$     \| $$         \$$  $$| $$   |  $$ \$$\
 \$$       \$$   \$$  \$$$$$$$ \$$          \$$$$  \$$    \$$   \$$
                                                                   
Repositorio creado con fines
de spammear via sms, ustedes
se hacen responsavles del uso
que le den. Necesitan termux
api para poder usarlo:
https://play.google.com/store/apps/details?id=com.termux.api

att

NePtYx
