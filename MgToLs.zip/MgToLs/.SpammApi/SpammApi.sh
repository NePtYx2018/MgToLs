apt install termux-api
clear
echo " __ _           _  _"
echo "(_ |_) _ __ __ |_||_) o"
echo "__)|  (_|||||||| ||   |"
echo "=========="
echo "by=NePtYx="
echo "=========="
echo ""
echo "Ingresa el numero que quieras"
echo "hacer spam sin el + integrado:"
read input
echo ""
echo "Ahora el mensaje:"
read input1
echo ""
clear
echo " __ _           _  _"
echo "(_ |_) _ __ __ |_||_) o"
echo "__)|  (_|||||||| ||   |"
echo "=========="
echo "by=NePtYx="
echo "=========="
echo "Selecciona cuantos mensajes enviaras:"
echo "=========="
echo "1)100sms ="
echo "=========="
read input2
clear
echo " __ _           _  _"
echo "(_ |_) _ __ __ |_||_) o"
echo "__)|  (_|||||||| ||   |"
echo "=========="
echo "by=NePtYx="
echo "=========="
echo ""
echo "Spammeando...Espere..."
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
termux-sms-send -n $input $input1
