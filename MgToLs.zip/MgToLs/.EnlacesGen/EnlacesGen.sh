clear
echo "Generador De Enlaces Maliciosos"
echo " "
echo "by NePtYx"
echo " "
echo "Escoge un link que deses generar:"
echo " "
echo "1)Capturacion_de_datos.sh"
echo "2)Instalador_de_cookies.sh"
echo "3)Crea_el_tuyo.sh"
echo "4)Exit.sh"
read input
./$input
echo "Error $input no se reconoce como archivo"
