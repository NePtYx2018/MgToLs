clear
echo "Generador De Enlaces Maliciosos"
echo " "
echo "by NePtYx"
echo " "
echo "¿Desea generar un capturador de datos?"
read input
echo "Generando..."
echo "*HEY!! Coca Cola esta regalando 700 Iphone XS* por" 
echo "su 132 Aniversario en su"
echo "pagina web aqui:"
echo "https://cocacoIa.com"
echo "Generado exitosamente..."
echo " "
echo "¿Desea volver al menu?"
read input2
echo "volviendo al menu..."
./EnlacesGen.sh
