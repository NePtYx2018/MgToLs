clear
echo "Router Device"
echo " "
echo "by NePtYx"
echo " "
echo "Escribe una de las opciones que quieres realizar:"
echo " "
echo "1)Obtenerip.sh"
echo "2)Ping.sh"
echo "3)Ddos.sh"
read input
./$input
