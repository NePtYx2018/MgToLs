clear
echo "___ _"
echo " | |_)|   _  _  _ _|_ _"
echo "_|_|  |__(_)(_ (_| |_(/_"
echo "=========="
echo "by=NePtYx="
echo "=========="
echo ""
echo "Introduce la ip publica:"
read input
echo ""
echo "Rastrado...¿Deseas verlo?"
read input1
clear
echo "___ _"
echo " | |_)|   _  _  _ _|_ _"
echo "_|_|  |__(_)(_ (_| |_(/_"
echo "=========="
echo "by=NePtYx="
echo "=========="
echo ""
echo "##############"
echo "#    Info    #"
echo "##############"
echo ""
curl ipinfo.io/$input
echo "$input Localizada con exito..."

