 _   _      ____  _ __   __
| \ | | ___|  _ \| |\ \ / /_  __
|  \| |/ _ \ |_) | __\ V /\ \/ /
| |\  |  __/  __/| |_ | |  >  <
|_| \_|\___|_|    \__||_| /_/\_\
Este programa esta echo con fines
educativos.Para entrar al router deseado
no es necesario estar en la misma red,
solo tener guardada la contraseña antigua
e haber entrado ya antes al router.No se sabe
si funcionara en otras redes como Claro, porque
la probamos en Movistar.
