bash .banner
echo "Selecciona la opcion, segun la persona a quien vallas a"
echo "usar el enlace de abajo:"
echo "========="
echo "1)Hacker="
echo "2)Normal="
echo "========="
read input
bash .$input
