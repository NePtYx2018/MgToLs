 __    __            _______     __  __      __          
|  \  |  \          |       \   |  \|  \    /  \         
| $$\ | $$  ______  | $$$$$$$\ _| $$_\$$\  /  $$__    __ 
| $$$\| $$ /      \ | $$__/ $$|   $$ \\$$\/  $$|  \  /  \
| $$$$\ $$|  $$$$$$\| $$    $$ \$$$$$$ \$$  $$  \$$\/  $$
| $$\$$ $$| $$    $$| $$$$$$$   | $$ __ \$$$$    >$$  $$ 
| $$ \$$$$| $$$$$$$$| $$        | $$|  \| $$    /  $$$$\ 
| $$  \$$$ \$$     \| $$         \$$  $$| $$   |  $$ \$$\
 \$$   \$$  \$$$$$$$ \$$          \$$$$  \$$    \$$   \$$

Este programa esta echo con 
fines educativos, no nos hacemos
responsavles por el mal uso que se 
les de y se recomienda usar con fines 
completamente educativos.

Uso:

1)Crea una cuenta de gmail para solamente spammear
y no utilizes tu cuenta personal.

2)Esta cuenta tiene que tener habilitado el acceso a apps
desconosias, si no el programa no funcionara.

3)Luego de eso debes usar un editor de texto para reemplazar
los datos que estan en el archivo conf.Los datos a editar
son tales como:

a)Tu correo de spam
b)Tu contraseña del correo spam
c)Correo de la victima

4)Tener el gmail de la persona que deseas spammear.
############
#Precaucion#
############                                             
Asegurate de cambiar cada sierto tiempo
tu gmail de spamm y crea otros, porque sino
Google te bloquea.
