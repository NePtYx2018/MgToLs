clear
sh .banner
echo "Selecciona la opcion que deseas hacer:"
echo "=========="
echo "1)Token  ="
echo "2)Spammer="
echo "=========="
read input
sh .$input
