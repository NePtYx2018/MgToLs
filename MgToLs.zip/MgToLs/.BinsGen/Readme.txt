
       __  __    __            _______     __  __      __          
      /  \|  \  |  \          |       \   |  \|  \    /  \         
     /  $$| $$\ | $$  ______  | $$$$$$$\ _| $$_\$$\  /  $$__    __ 
    /  $$ | $$$\| $$ /      \ | $$__/ $$|   $$ \\$$\/  $$|  \  /  \
   /  $$  | $$$$\ $$|  $$$$$$\| $$    $$ \$$$$$$ \$$  $$  \$$\/  $$
  /  $$   | $$\$$ $$| $$    $$| $$$$$$$   | $$ __ \$$$$    >$$  $$ 
 /  $$    | $$ \$$$$| $$$$$$$$| $$        | $$|  \| $$    /  $$$$\ 
|  $$     | $$  \$$$ \$$     \| $$         \$$  $$| $$   |  $$ \$$\
 \$$       \$$   \$$  \$$$$$$$ \$$          \$$$$  \$$    \$$   \$$
                                                                   
Repositorio creado para la clonacion
de bins y tarjetas, no nos hacemos responsables
por el uso de este ya sea bueno o malo.
Formula del bin:
Bin escrito:
combinacion1
combinacion2
...
att

NePtYx
