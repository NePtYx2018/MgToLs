clear
echo " _           __"
echo "|_) o __  _ /__ _ __"
echo "|_) | | |_> \_|(/_| |"
echo "=========="
echo "by=NePtYx="
echo "=========="
python .1.py
