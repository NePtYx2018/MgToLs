clear
chmod 777 Menu.sh
echo "============================="
echo "=Creador De Virus Para Linux="
echo "============================="
echo "=by=NePtYx="
echo "==========="
echo " "
echo "Selecciona cual de estos virus deseas"
echo "crear:"
echo " "
echo "Opcion: V1.sh"
echo "El virus creado desde ayi dañara los archivos"
echo "de quien los ejecute (Linux)."
echo "Opcion: V2.sh"
echo "El virus creado desde ayi eliminara todos los "
echo "archivos de la victima"
echo "=============================================="
echo "Escribe V1.sh o V2.sh para acceder al menu"
echo "de su creacion:"
read input 
bash $input
