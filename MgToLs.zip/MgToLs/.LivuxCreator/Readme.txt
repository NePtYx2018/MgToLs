
       /$$ /$$   /$$           /$$$$$$$    /$$  /$$     /$$        
      /$$/| $$$ | $$          | $$__  $$  | $$ |  $$   /$$/        
     /$$/ | $$$$| $$  /$$$$$$ | $$  \ $$ /$$$$$$\  $$ /$$//$$   /$$
    /$$/  | $$ $$ $$ /$$__  $$| $$$$$$$/|_  $$_/ \  $$$$/|  $$ /$$/
   /$$/   | $$  $$$$| $$$$$$$$| $$____/   | $$    \  $$/  \  $$$$/ 
  /$$/    | $$\  $$$| $$_____/| $$        | $$ /$$ | $$    >$$  $$ 
 /$$/     | $$ \  $$|  $$$$$$$| $$        |  $$$$/ | $$   /$$/\  $$
|__/      |__/  \__/ \_______/|__/         \___/   |__/  |__/  \__/
                                                                   
                                                                   
Este repositorio esta hecho con todo
cariño para mis subscriptores y personas 
que conosco. Usenlo con responsavilidad
y no dañen a personas por molestar,haganlo 
por un echo que tenga validez, se recomienda
usar ingenieria social.

Att

NePtYx                                                                   

