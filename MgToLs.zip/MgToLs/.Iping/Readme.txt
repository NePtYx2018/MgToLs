 _   _      ____  _ __   __
| \ | | ___|  _ \| |\ \ / /_  __
|  \| |/ _ \ |_) | __\ V /\ \/ /
| |\  |  __/  __/| |_ | |  >  <
|_| \_|\___|_|    \__||_| /_/\_\
////////////////////////////////
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

Instrucciones de uso:
#####################

Al entrar en la pantalla de inicio tendras 2 opciones,crear un
servidor dentro de tu red local,y la opcion de crear fuera de la red
local,la anterior mensionada se tiene que realizar activando la primera
en una ventana y la segunda en otra ventana.

Dentro de red:
¤¤¤¤¤¤¤¤¤¤¤¤¤¤

Si escogiste esta opcion si lo que deseas es almacenar una web es mover
el index.html a la carpeta: Download© para luego ejecutar el servidor que te
quedara algo asi: http://181.234.242.1:8080 para luego editar el enlace y colocarle el
nombre de tu index: http://181.234.242.1:8080/index.html. Pero si deseas un enlace 
que descarge archivos maliciosos solo debes de hacer lo mismo, mover a la carpeta: Download©
para luego encender el servidor. (Al final deverias de conpartir tu enlace que quedaria asi: 
http://181.234.242.1:8080/Archivo.sh.

Fuera de red:
¤¤¤¤¤¤¤¤¤¤¤¤¤

Para hacer el enlace fuera de la red debes de ensender el de la red local y el de fuera de la red
asi estos dos se complementaran y formaran un servidor fuera de la red. El enlace deberia
de quedar algo asi: https://serveo.com. Y haras lo mismo con estos ya sea si es un index o un 
archivo debio quedarte algo asi: https://serveo.com/archivo.html

¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥¥
No nos hacemos responsables por su uso esto esta hecho con fines educativos.
