 __    __            _______     __  __      __
|  \  |  \          |       \   |  \|  \    /  \
| $$\ | $$  ______  | $$$$$$$\ _| $$_\$$\  /  $$__    __
| $$$\| $$ /      \ | $$__/ $$|   $$ \\$$\/  $$|  \  /  \
| $$$$\ $$|  $$$$$$\| $$    $$ \$$$$$$ \$$  $$  \$$\/  $$
| $$\$$ $$| $$    $$| $$$$$$$   | $$ __ \$$$$    >$$  $$
| $$ \$$$$| $$$$$$$$| $$        | $$|  \| $$    /  $$$$\
| $$  \$$$ \$$     \| $$         \$$  $$| $$   |  $$ \$$\
 \$$   \$$  \$$$$$$$ \$$          \$$$$  \$$    \$$   \$$
Este repositorio esta creado con 
fines de como es que se efectuan los ataques 
de spamm, dicho esto ya estas advertido.
No nos hacemos responsables del uso que se le
de.
