bash .banner
echo "Que deseas realizar:"
echo "=================="
echo "1)Seleccionar url="
echo "2)Minar la url   ="
echo "=================="
read input
bash .$input
