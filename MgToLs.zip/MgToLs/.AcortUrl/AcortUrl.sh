bash .banner
echo "Introduce la url que deseas acortar:"
read input
bash .banner
echo "Aqui esta tu link acortado..."
echo "Link:"
echo "http://adf.ly/20875421/$input"
echo ""
echo "Saliendo..."
