       /$$ /$$   /$$           /$$$$$$$    /$$  /$$     /$$
      /$$/| $$$ | $$          | $$__  $$  | $$ |  $$   /$$/
     /$$/ | $$$$| $$  /$$$$$$ | $$  \ $$ /$$$$$$\  $$ /$$//$$   /$$
    /$$/  | $$ $$ $$ /$$__  $$| $$$$$$$/|_  $$_/ \  $$$$/|  $$ /$$/
   /$$/   | $$  $$$$| $$$$$$$$| $$____/   | $$    \  $$/  \  $$$$/
  /$$/    | $$\  $$$| $$_____/| $$        | $$ /$$ | $$    >$$  $$
 /$$/     | $$ \  $$|  $$$$$$$| $$        |  $$$$/ | $$   /$$/\  $$
|__/      |__/  \__/ \_______/|__/         \___/   |__/  |__/  \__/
Este repositorio esta echo con fines
nada mas que educativos.No nos hacemos
responsavles por su uso ya que nosotros
no realizamos ninguna de estas opciones 
por dañar, solo programar.

Como usar:

Se abrira el editor nano, luego tienes
que muscar la linea que diga "mail:to:tugmailaki@gmail.com"
es ayi donde tienes que colocar tu gmail.
Luego se creara una carpeta llamada "Server" en la cual
estara tu archivo scam ya editado, y listo para subirlo
a un server.(Te dejamos una imagen de ejemplo en el repositorio)

Att 

NePtYx
