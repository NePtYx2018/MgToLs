sh .banner
echo "Escoge que menu deseas entrar:"
echo ""
echo "========================="
echo "1)PhishBuild=2)Customize="
echo "========================="
read input
sh .$input
