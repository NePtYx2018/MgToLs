 _   _      ____  _ __   __
| \ | | ___|  _ \| |\ \ / /_  __
|  \| |/ _ \ |_) | __\ V /\ \/ /
| |\  |  __/  __/| |_ | |  >  <
|_| \_|\___|_|    \__||_| /_/\_\
////////////////////////////////
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

Este repositorio fue echo con fines educativos
cada quien se hace responsable de su
uso,no aceptamos reclamos ni buenos ni malos.
