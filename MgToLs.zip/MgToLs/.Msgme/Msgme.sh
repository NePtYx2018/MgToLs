bash .banner
echo "Introduce lo que deseas hacer:"
echo "=============="
echo "1)Como usar  ="
echo "2)Generar url="
echo "=============="
read input
bash .$input