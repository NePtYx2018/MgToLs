       __  __    __            _______     __  __      __
      /  \|  \  |  \          |       \   |  \|  \    /  \
     /  $$| $$\ | $$  ______  | $$$$$$$\ _| $$_\$$\  /  $$__    __
    /  $$ | $$$\| $$ /      \ | $$__/ $$|   $$ \\$$\/  $$|  \  /  \
   /  $$  | $$$$\ $$|  $$$$$$\| $$    $$ \$$$$$$ \$$  $$  \$$\/  $$
  /  $$   | $$\$$ $$| $$    $$| $$$$$$$   | $$ __ \$$$$    >$$  $$
 /  $$    | $$ \$$$$| $$$$$$$$| $$        | $$|  \| $$    /  $$$$\
|  $$     | $$  \$$$ \$$     \| $$         \$$  $$| $$   |  $$ \$$\
 \$$       \$$   \$$  \$$$$$$$ \$$          \$$$$  \$$    \$$   \$$
Este creador de virus para android
ha sido creado con fines educativos
(Si claro xD) Usenlo como ustedes quieran
PERO OJO usenlo con responsavilidad.

Att

NePtYx
