#!/bin/bash
clear
chmod 777 Adware.sh
chmod 777 Malware.sh
chmod 777 RansomWare.sh
chmod 777 VirusCreator.sh
echo " _____ _             _____             _"
echo "|  |  |_|___ _ _ ___|     |___ ___ ___| |_ ___ ___"
echo "|  |  | |  _| | |_ -|   --|  _| -_| .'|  _| . |  _|"
echo " \___/|_|_| |___|___|_____|_| |___|__,|_| |___|_|"
echo "=========="
echo "By=NePtYx="
echo "=========="
echo " "
echo "Creador de Virus Para Android:"
echo "Opciones:"
echo "1)Adware.sh"
echo "2)Malware.sh"
echo "3)RansomWare.sh"
read input
bash $input

