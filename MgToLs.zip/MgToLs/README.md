
       __  __    __            _______     __  __      __          
      /  \|  \  |  \          |       \   |  \|  \    /  \         
     /  $$| $$\ | $$  ______  | $$$$$$$\ _| $$_\$$\  /  $$__    __ 
    /  $$ | $$$\| $$ /      \ | $$__/ $$|   $$ \\$$\/  $$|  \  /  \
   /  $$  | $$$$\ $$|  $$$$$$\| $$    $$ \$$$$$$ \$$  $$  \$$\/  $$
  /  $$   | $$\$$ $$| $$    $$| $$$$$$$   | $$ __ \$$$$    >$$  $$ 
 /  $$    | $$ \$$$$| $$$$$$$$| $$        | $$|  \| $$    /  $$$$\ 
|  $$     | $$  \$$$ \$$     \| $$         \$$  $$| $$   |  $$ \$$\
 \$$       \$$   \$$  \$$$$$$$ \$$          \$$$$  \$$    \$$   \$$
                                                                   
Menu de Cracks y herramientas de pentesting
para tu termux y linux, este Menu junto con
todos sus repositorios influyentes, fueron
creados por NePtYx no nos hacemos responsables
por el uso de estas y cualquier reclamo sera 
ignorado.

Att

NePtYx
